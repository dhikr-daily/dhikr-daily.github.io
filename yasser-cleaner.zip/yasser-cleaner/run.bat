@echo off
cd /d "%~dp0"
start "" pyw -3.11 app.py
