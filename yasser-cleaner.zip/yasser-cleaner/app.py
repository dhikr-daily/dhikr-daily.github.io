import threading, tkinter as tk
from tkinter import filedialog, ttk
import cleaner

class A:
    threshold=-35; min_silence=5.0; pad=0; volume=-4; zoom=2.0; no_denoise=False
    vertical=False; captions=True; lang="ar"; model="small"; font="Amiri"; font_size=16; output=None

root = tk.Tk(); root.title("منظف الفيديو - ياسر"); root.geometry("560x380")
path = tk.StringVar(); cap = tk.BooleanVar(value=True); vert = tk.BooleanVar(value=False)
tk.Button(root, text="اختار الفيديو", command=lambda: path.set(filedialog.askopenfilename(
    filetypes=[("Video","*.mp4 *.mov *.mkv *.avi *.webm")])), font=("Segoe UI",12)).pack(pady=10)
tk.Label(root, textvariable=path, wraplength=520).pack()
tk.Checkbutton(root, text="كتابة عربي تلقائية (أبطأ)", variable=cap).pack()
tk.Checkbutton(root, text="فيديو 9:16 (1080x1920)", variable=vert).pack()
log = tk.Text(root, height=10); log.pack(fill="both", padx=10, pady=8)
def say(m): log.insert("end", m+"\n"); log.see("end")
def work():
    a = A(); a.input = path.get(); a.captions = cap.get(); a.vertical = vert.get()
    try: cleaner.process(a, lambda m: root.after(0, say, m))
    except Exception as e: root.after(0, say, "خطأ: %s" % e)
    root.after(0, lambda: btn.config(state="normal"))
def go():
    if not path.get(): return
    btn.config(state="disabled"); threading.Thread(target=work, daemon=True).start()
btn = tk.Button(root, text="ابدأ", command=go, font=("Segoe UI",14), bg="#2e7d32", fg="white"); btn.pack(pady=6)
root.mainloop()
