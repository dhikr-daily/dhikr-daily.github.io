"""Yasser Video Cleaner - cuts silence, denoises, -4dB, 200% zoom, optional Arabic captions."""
import argparse, json, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
def tool(n):
    p = os.path.join(HERE, "bin", n + (".exe" if os.name == "nt" else ""))
    return p if os.path.exists(p) else n
MAX_SILENCE = 2.5
FFMPEG, FFPROBE = tool("ffmpeg"), tool("ffprobe")
NOFLASH = 0x08000000 if os.name == "nt" else 0

def run(cmd, **kw):
    return subprocess.run(cmd, creationflags=NOFLASH, **kw)

def probe(path):
    r = run([FFPROBE, "-v", "error", "-show_entries", "stream=codec_type,width,height,duration",
             "-show_entries", "format=duration", "-of", "json", path], capture_output=True, text=True)
    j = json.loads(r.stdout)
    v = next((s for s in j["streams"] if s["codec_type"] == "video"), None)
    return float(j["format"]["duration"]), (int(v["width"]), int(v["height"])) if v else None

def detect_keep(path, dur, thresh_db, min_sil, pad, log):
    """Silences longer than min_sil (5s) are shortened to max_sil (2.5s). Shorter pauses stay untouched."""
    log("Detecting silence...")
    af = "highpass=f=80,afftdn=nf=-25,silencedetect=noise=%ddB:d=%s" % (thresh_db, min_sil)
    r = run([FFMPEG, "-hide_banner", "-nostats", "-i", path, "-vn", "-af", af, "-f", "null", "-"],
            capture_output=True, text=True, errors="replace")
    starts = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", r.stderr)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r.stderr)]
    keep, pos = [], 0.0
    half = MAX_SILENCE / 2.0
    for i, s in enumerate(starts):
        s = max(0.0, s); e = ends[i] if i < len(ends) else dur
        if e - s <= min_sil: continue
        cut_a, cut_b = s + half, e - half   # remove the middle, keep 1.25s on each side = 2.5s total
        if cut_a > pos: keep.append((pos, cut_a))
        pos = cut_b
    if dur - pos > 0.05: keep.append((pos, dur))
    return keep

def render(src, out, segs, size, zoom, vol_db, denoise, vertical, log):
    expr = "+".join("between(t,%.3f,%.3f)" % (a, b) for a, b in segs) or "1"
    w, h = size
    vf = ["select='%s'" % expr, "setpts=N/FRAME_RATE/TB"]
    if zoom and zoom > 1:
        vf.append("crop=trunc(iw/%s/2)*2:trunc(ih/%s/2)*2" % (zoom, zoom))
    if vertical: vf.append("scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920")
    else: vf.append("scale=%d:%d" % (w, h))
    vf.append("setsar=1")
    af = ["aselect='%s'" % expr, "asetpts=N/SR/TB"]
    if denoise: af += ["highpass=f=80", "afftdn=nf=-25:nr=18", "equalizer=f=250:t=q:w=1:g=-2", "equalizer=f=3500:t=q:w=1:g=3", "acompressor=threshold=-20dB:ratio=3:attack=10:release=150", "alimiter=limit=0.95"]
    af.append("volume=%sdB" % vol_db)
    with tempfile.TemporaryDirectory() as d:
        vs, as_ = os.path.join(d, "v.txt"), os.path.join(d, "a.txt")
        open(vs, "w").write(",".join(vf)); open(as_, "w").write(",".join(af))
        cmd = [FFMPEG, "-y", "-hide_banner", "-i", src, "-filter_script:v", vs, "-filter_script:a", as_,
               "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p",
               "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out]
        log("Rendering...")
        r = run(cmd, capture_output=True, text=True, errors="replace")
        if r.returncode: raise RuntimeError(r.stderr[-1500:])

def transcribe(path, srt, lang, model, log):
    from faster_whisper import WhisperModel
    log("Transcribing (first run downloads the model)...")
    m = WhisperModel(model, device="cpu", compute_type="int8")
    segs, _ = m.transcribe(path, language=lang, vad_filter=True, beam_size=5)
    def ts(t):
        h, rem = divmod(t, 3600); mi, s = divmod(rem, 60)
        return "%02d:%02d:%06.3f" % (h, mi, s) .replace(".", ",")
    n = 0
    with open(srt, "w", encoding="utf-8") as f:
        for s in segs:
            n += 1
            f.write("%d\n%s --> %s\n%s\n\n" % (n, ts(s.start), ts(s.end), s.text.strip()))
    return n

def burn(src, srt, out, font, size, log):
    log("Burning captions...")
    fontsdir = os.path.join(HERE, "fonts")
    p = lambda x: x.replace("\\", "/").replace(":", "\\:")
    style = "FontName=%s,FontSize=%d,Bold=1,PrimaryColour=&HFFFFFF&,OutlineColour=&H000000&,Outline=3,Alignment=2,MarginV=%d" % (font, size, 120)
    vf = "subtitles='%s':fontsdir='%s':force_style='%s'" % (p(srt), p(fontsdir), style)
    r = run([FFMPEG, "-y", "-hide_banner", "-i", src, "-vf", vf, "-c:v", "libx264", "-preset", "medium",
             "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "copy", out], capture_output=True, text=True, errors="replace")
    if r.returncode: raise RuntimeError(r.stderr[-1500:])

def process(a, log=print):
    dur, size = probe(a.input)
    base = os.path.splitext(a.input)[0]
    out = a.output or base + "_clean.mp4"
    segs = detect_keep(a.input, dur, a.threshold, a.min_silence, a.pad, log)
    kept = sum(b - x for x, b in segs)
    log("Keeping %.1f of %.1f min (%d pieces)" % (kept / 60, dur / 60, len(segs)))
    final = out
    tmp = base + "_nocap.mp4" if a.captions else out
    render(a.input, tmp, segs, size, a.zoom, a.volume, not a.no_denoise, a.vertical, log)
    if a.captions:
        srt = base + "_clean.srt"
        n = transcribe(tmp, srt, a.lang, a.model, log)
        log("%d caption lines. You can edit %s then re-run burn." % (n, srt))
        burn(tmp, srt, final, a.font, a.font_size, log)
        os.remove(tmp)
    log("Done: " + final)
    return final

def parser():
    p = argparse.ArgumentParser()
    p.add_argument("input"); p.add_argument("-o", "--output")
    p.add_argument("--threshold", type=int, default=-35, help="silence level dB")
    p.add_argument("--min-silence", type=float, default=5.0, help="only silences longer than this (s) are shortened to 2.5s")
    p.add_argument("--pad", type=float, default=0)
    p.add_argument("--volume", type=float, default=-4)
    p.add_argument("--zoom", type=float, default=2.0)
    p.add_argument("--no-denoise", action="store_true")
    p.add_argument("--vertical", action="store_true", help="output 1080x1920")
    p.add_argument("--captions", action="store_true")
    p.add_argument("--lang", default="ar"); p.add_argument("--model", default="small")
    p.add_argument("--font", default="Amiri"); p.add_argument("--font-size", type=int, default=16)
    return p

if __name__ == "__main__":
    process(parser().parse_args())
