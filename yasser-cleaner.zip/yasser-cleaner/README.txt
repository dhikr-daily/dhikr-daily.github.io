1) Run setup.bat once (needs internet).
2) Open run.bat, pick the video, press Start.
Output: <name>_clean.mp4 (+ .srt captions file).
Does: silences over 5s cut to 2.5s, noise reduction + voice clarity, volume -4dB, 200% zoom.
Command line: py cleaner.py video.mp4 --captions --vertical
