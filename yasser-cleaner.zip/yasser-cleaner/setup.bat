@echo off
echo Installing (one time)...
winget install -e --id Python.Python.3.11 --accept-package-agreements --accept-source-agreements
winget install -e --id Gyan.FFmpeg --accept-package-agreements --accept-source-agreements
py -3.11 -m pip install faster-whisper
echo Done. Close this window and open run.bat
pause
